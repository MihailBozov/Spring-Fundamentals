package com.philately;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhilatelyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhilatelyApplication.class, args);
	}

}
